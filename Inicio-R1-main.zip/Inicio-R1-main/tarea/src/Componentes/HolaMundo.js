
import React from 'react';
import './HolaMundo.css';

const HolaMundo = () => {
    return (
        <div className="contenedor">
            <h1 className="h1">Hola Mundo</h1>
        </div>
    );
};

export default HolaMundo;
